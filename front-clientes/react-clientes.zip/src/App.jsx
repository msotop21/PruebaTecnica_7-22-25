import React from 'react';
import ClienteForm from './ClienteForm';

function App() {
  return (
    <div>
      <ClienteForm />
    </div>
  );
}

export default App;
